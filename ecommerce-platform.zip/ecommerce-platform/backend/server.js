import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import stripe from 'stripe';
import { v4 as uuidv4 } from 'uuid';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;
const stripeClient = stripe(process.env.STRIPE_SECRET_KEY || 'sk_test_demo');

// Middleware
app.use(cors());
app.use(express.json());

// ========================================
// IN-MEMORY DATABASE (Replace with MongoDB)
// ========================================

let users = [];
let products = [];
let orders = [];
let carts = [];

// Sample Products
const sampleProducts = [
  {
    id: '1',
    name: 'Wireless Headphones',
    price: 2999,
    category: 'Electronics',
    image: 'https://via.placeholder.com/300x300?text=Headphones',
    description: 'High-quality wireless headphones with noise cancellation',
    stock: 50,
    rating: 4.5
  },
  {
    id: '2',
    name: 'Smart Watch',
    price: 5999,
    category: 'Electronics',
    image: 'https://via.placeholder.com/300x300?text=SmartWatch',
    description: 'Feature-rich smartwatch with health monitoring',
    stock: 30,
    rating: 4.3
  },
  {
    id: '3',
    name: 'USB-C Cable',
    price: 499,
    category: 'Accessories',
    image: 'https://via.placeholder.com/300x300?text=Cable',
    description: 'Durable USB-C charging cable',
    stock: 200,
    rating: 4.8
  },
  {
    id: '4',
    name: 'Phone Case',
    price: 799,
    category: 'Accessories',
    image: 'https://via.placeholder.com/300x300?text=Case',
    description: 'Protective phone case with anti-shock technology',
    stock: 150,
    rating: 4.6
  },
  {
    id: '5',
    name: 'Laptop Stand',
    price: 1299,
    category: 'Accessories',
    image: 'https://via.placeholder.com/300x300?text=Stand',
    description: 'Adjustable aluminum laptop stand',
    stock: 75,
    rating: 4.7
  },
  {
    id: '6',
    name: 'Portable Charger',
    price: 1799,
    category: 'Electronics',
    image: 'https://via.placeholder.com/300x300?text=Charger',
    description: 'Fast charging power bank with 20000mAh capacity',
    stock: 100,
    rating: 4.4
  }
];

products.push(...sampleProducts);

// ========================================
// AUTHENTICATION ENDPOINTS
// ========================================

// Register
app.post('/api/auth/register', (req, res) => {
  try {
    const { email, password, name } = req.body;

    if (!email || !password || !name) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const existingUser = users.find(u => u.email === email);
    if (existingUser) {
      return res.status(400).json({ error: 'User already exists' });
    }

    const hashedPassword = bcrypt.hashSync(password, 10);
    const user = {
      id: uuidv4(),
      email,
      password: hashedPassword,
      name,
      createdAt: new Date().toISOString()
    };

    users.push(user);

    const token = jwt.sign({ id: user.id, email: user.email }, 'SECRET_KEY', { expiresIn: '7d' });

    res.status(201).json({
      success: true,
      message: 'User registered successfully',
      token,
      user: { id: user.id, email: user.email, name: user.name }
    });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Login
app.post('/api/auth/login', (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password required' });
    }

    const user = users.find(u => u.email === email);
    if (!user || !bcrypt.compareSync(password, user.password)) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = jwt.sign({ id: user.id, email: user.email }, 'SECRET_KEY', { expiresIn: '7d' });

    res.json({
      success: true,
      token,
      user: { id: user.id, email: user.email, name: user.name }
    });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// ========================================
// PRODUCTS ENDPOINTS
// ========================================

// Get all products
app.get('/api/products', (req, res) => {
  try {
    const { category, search, sort } = req.query;
    
    let filtered = [...products];

    if (category) {
      filtered = filtered.filter(p => p.category === category);
    }

    if (search) {
      filtered = filtered.filter(p => 
        p.name.toLowerCase().includes(search.toLowerCase())
      );
    }

    if (sort === 'price-low') {
      filtered.sort((a, b) => a.price - b.price);
    } else if (sort === 'price-high') {
      filtered.sort((a, b) => b.price - a.price);
    } else if (sort === 'rating') {
      filtered.sort((a, b) => b.rating - a.rating);
    }

    res.json({ success: true, products: filtered });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Get single product
app.get('/api/products/:id', (req, res) => {
  try {
    const product = products.find(p => p.id === req.params.id);
    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }
    res.json({ success: true, product });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Get categories
app.get('/api/categories', (req, res) => {
  const categories = [...new Set(products.map(p => p.category))];
  res.json({ success: true, categories });
});

// ========================================
// CART ENDPOINTS
// ========================================

// Get cart
app.get('/api/cart/:userId', (req, res) => {
  try {
    let cart = carts.find(c => c.userId === req.params.userId);
    if (!cart) {
      cart = { userId: req.params.userId, items: [] };
      carts.push(cart);
    }

    const cartWithDetails = {
      ...cart,
      items: cart.items.map(item => {
        const product = products.find(p => p.id === item.productId);
        return { ...item, product };
      })
    };

    const total = cartWithDetails.items.reduce((sum, item) => 
      sum + (item.product?.price || 0) * item.quantity, 0
    );

    res.json({ success: true, cart: cartWithDetails, total });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Add to cart
app.post('/api/cart/add', (req, res) => {
  try {
    const { userId, productId, quantity } = req.body;

    let cart = carts.find(c => c.userId === userId);
    if (!cart) {
      cart = { userId, items: [] };
      carts.push(cart);
    }

    const existingItem = cart.items.find(i => i.productId === productId);
    if (existingItem) {
      existingItem.quantity += quantity;
    } else {
      cart.items.push({ id: uuidv4(), productId, quantity });
    }

    res.json({ success: true, message: 'Added to cart', cart });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Remove from cart
app.post('/api/cart/remove', (req, res) => {
  try {
    const { userId, itemId } = req.body;

    const cart = carts.find(c => c.userId === userId);
    if (!cart) {
      return res.status(404).json({ error: 'Cart not found' });
    }

    cart.items = cart.items.filter(i => i.id !== itemId);
    res.json({ success: true, message: 'Removed from cart', cart });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Update cart item quantity
app.post('/api/cart/update', (req, res) => {
  try {
    const { userId, itemId, quantity } = req.body;

    const cart = carts.find(c => c.userId === userId);
    if (!cart) {
      return res.status(404).json({ error: 'Cart not found' });
    }

    const item = cart.items.find(i => i.id === itemId);
    if (!item) {
      return res.status(404).json({ error: 'Item not found' });
    }

    if (quantity <= 0) {
      cart.items = cart.items.filter(i => i.id !== itemId);
    } else {
      item.quantity = quantity;
    }

    res.json({ success: true, cart });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// ========================================
// ORDERS ENDPOINTS
// ========================================

// Create order
app.post('/api/orders/create', (req, res) => {
  try {
    const { userId, items, total, shippingAddress } = req.body;

    const order = {
      id: uuidv4(),
      userId,
      items,
      total,
      shippingAddress,
      status: 'pending',
      paymentStatus: 'unpaid',
      createdAt: new Date().toISOString()
    };

    orders.push(order);
    res.status(201).json({ success: true, order });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Get user orders
app.get('/api/orders/:userId', (req, res) => {
  try {
    const userOrders = orders.filter(o => o.userId === req.params.userId);
    res.json({ success: true, orders: userOrders });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Get single order
app.get('/api/orders/detail/:orderId', (req, res) => {
  try {
    const order = orders.find(o => o.id === req.params.orderId);
    if (!order) {
      return res.status(404).json({ error: 'Order not found' });
    }
    res.json({ success: true, order });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// ========================================
// PAYMENT ENDPOINTS
// ========================================

// Create payment intent
app.post('/api/payments/create-intent', (req, res) => {
  try {
    const { amount, orderId } = req.body;

    // For demo, we're simulating Stripe
    const paymentIntent = {
      id: uuidv4(),
      clientSecret: uuidv4(),
      amount,
      orderId,
      status: 'created',
      createdAt: new Date().toISOString()
    };

    res.json({ 
      success: true, 
      clientSecret: paymentIntent.clientSecret,
      paymentIntentId: paymentIntent.id
    });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Confirm payment
app.post('/api/payments/confirm', (req, res) => {
  try {
    const { orderId, paymentIntentId } = req.body;

    const order = orders.find(o => o.id === orderId);
    if (!order) {
      return res.status(404).json({ error: 'Order not found' });
    }

    order.paymentStatus = 'paid';
    order.status = 'confirmed';

    res.json({ 
      success: true, 
      message: 'Payment confirmed',
      order 
    });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// ========================================
// ADMIN ENDPOINTS
// ========================================

// Get all orders (admin)
app.get('/api/admin/orders', (req, res) => {
  try {
    res.json({ success: true, orders });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Get admin dashboard stats
app.get('/api/admin/stats', (req, res) => {
  try {
    const totalOrders = orders.length;
    const totalRevenue = orders.reduce((sum, o) => sum + (o.paymentStatus === 'paid' ? o.total : 0), 0);
    const totalProducts = products.length;
    const totalUsers = users.length;
    const paidOrders = orders.filter(o => o.paymentStatus === 'paid').length;
    const pendingOrders = orders.filter(o => o.status === 'pending').length;

    const stats = {
      totalOrders,
      totalRevenue,
      totalProducts,
      totalUsers,
      paidOrders,
      pendingOrders,
      recentOrders: orders.slice(-5).reverse()
    };

    res.json({ success: true, stats });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Update order status (admin)
app.put('/api/admin/orders/:orderId', (req, res) => {
  try {
    const { status } = req.body;
    const order = orders.find(o => o.id === req.params.orderId);
    if (!order) {
      return res.status(404).json({ error: 'Order not found' });
    }
    order.status = status;
    res.json({ success: true, order });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Add product (admin)
app.post('/api/admin/products', (req, res) => {
  try {
    const { name, price, category, description, stock } = req.body;
    const product = {
      id: uuidv4(),
      name,
      price,
      category,
      description,
      stock,
      image: 'https://via.placeholder.com/300x300?text=' + name,
      rating: 4.5,
      createdAt: new Date().toISOString()
    };
    products.push(product);
    res.status(201).json({ success: true, product });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Update product (admin)
app.put('/api/admin/products/:productId', (req, res) => {
  try {
    const product = products.find(p => p.id === req.params.productId);
    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }
    Object.assign(product, req.body);
    res.json({ success: true, product });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Delete product (admin)
app.delete('/api/admin/products/:productId', (req, res) => {
  try {
    const index = products.findIndex(p => p.id === req.params.productId);
    if (index === -1) {
      return res.status(404).json({ error: 'Product not found' });
    }
    products.splice(index, 1);
    res.json({ success: true, message: 'Product deleted' });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// ========================================
// HEALTH CHECK
// ========================================

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', message: 'E-Commerce API is running' });
});

app.get('/', (req, res) => {
  res.json({
    name: 'Professional E-Commerce Platform',
    version: '1.0.0',
    features: ['Product Catalog', 'Shopping Cart', 'Payment Integration', 'Admin Panel', 'Order Management']
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`
╔════════════════════════════════════════════════╗
║  Professional E-Commerce API                   ║
║  Running on http://localhost:${PORT}              ║
║  Database: In-Memory (ready for MongoDB)       ║
╚════════════════════════════════════════════════╝
  `);
});

export default app;
