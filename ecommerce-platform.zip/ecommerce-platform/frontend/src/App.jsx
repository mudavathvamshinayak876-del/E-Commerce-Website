import { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import './App.css';
import { FiShoppingCart, FiUser, FiSearch, FiLogOut, FiHome, FiBox, FiPackage } from 'react-icons/fi';

const API_URL = 'http://localhost:5000/api';

// ========================================
// PRODUCTS PAGE
// ========================================
function ProductsPage() {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(false);
  const userId = localStorage.getItem('userId');
  const navigate = useNavigate();

  useEffect(() => {
    fetchProducts();
    fetchCategories();
  }, [selectedCategory, searchTerm]);

  const fetchProducts = async () => {
    try {
      setLoading(true);
      let url = `${API_URL}/products?`;
      if (selectedCategory) url += `category=${selectedCategory}&`;
      if (searchTerm) url += `search=${searchTerm}`;
      
      const response = await axios.get(url);
      setProducts(response.data.products);
    } catch (error) {
      console.error('Error fetching products:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchCategories = async () => {
    try {
      const response = await axios.get(`${API_URL}/categories`);
      setCategories(response.data.categories);
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  };

  const addToCart = async (product) => {
    if (!userId) {
      alert('Please login first');
      navigate('/login');
      return;
    }

    try {
      await axios.post(`${API_URL}/cart/add`, {
        userId,
        productId: product.id,
        quantity: 1
      });
      alert('✅ Added to cart!');
    } catch (error) {
      console.error('Error adding to cart:', error);
      alert('Error adding to cart');
    }
  };

  return (
    <div className="products-page">
      <div className="filters">
        <input
          type="text"
          placeholder="Search products..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="search-input"
        />
        
        <div className="categories">
          <button
            className={!selectedCategory ? 'active' : ''}
            onClick={() => setSelectedCategory('')}
          >
            All
          </button>
          {categories.map(cat => (
            <button
              key={cat}
              className={selectedCategory === cat ? 'active' : ''}
              onClick={() => setSelectedCategory(cat)}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <p>Loading...</p>
      ) : (
        <div className="products-grid">
          {products.map(product => (
            <div key={product.id} className="product-card">
              <img src={product.image} alt={product.name} />
              <h3>{product.name}</h3>
              <p className="description">{product.description}</p>
              <div className="product-footer">
                <span className="price">₹{product.price}</span>
                <span className="rating">⭐ {product.rating}</span>
              </div>
              <div className="product-actions">
                <Link to={`/product/${product.id}`} className="btn-view">View</Link>
                <button onClick={() => addToCart(product)} className="btn-cart">
                  Add to Cart
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ========================================
// PRODUCT DETAIL PAGE
// ========================================
function ProductDetailPage() {
  const { productId } = useParams();
  const [product, setProduct] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const userId = localStorage.getItem('userId');
  const navigate = useNavigate();

  useEffect(() => {
    fetchProduct();
  }, [productId]);

  const fetchProduct = async () => {
    try {
      const response = await axios.get(`${API_URL}/products/${productId}`);
      setProduct(response.data.product);
    } catch (error) {
      console.error('Error fetching product:', error);
    }
  };

  const addToCart = async () => {
    if (!userId) {
      alert('Please login first');
      navigate('/login');
      return;
    }

    try {
      await axios.post(`${API_URL}/cart/add`, {
        userId,
        productId: product.id,
        quantity: parseInt(quantity)
      });
      alert('✅ Added to cart!');
    } catch (error) {
      alert('Error adding to cart');
    }
  };

  if (!product) return <p>Loading...</p>;

  return (
    <div className="product-detail">
      <button onClick={() => navigate(-1)} className="back-btn">← Back</button>
      
      <div className="detail-container">
        <div className="detail-image">
          <img src={product.image} alt={product.name} />
        </div>
        
        <div className="detail-info">
          <h1>{product.name}</h1>
          <p className="detail-description">{product.description}</p>
          
          <div className="detail-specs">
            <p><strong>Price:</strong> ₹{product.price}</p>
            <p><strong>Stock:</strong> {product.stock} available</p>
            <p><strong>Category:</strong> {product.category}</p>
            <p><strong>Rating:</strong> ⭐ {product.rating}</p>
          </div>

          <div className="detail-purchase">
            <div className="quantity-selector">
              <label>Quantity:</label>
              <input
                type="number"
                min="1"
                max={product.stock}
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
              />
            </div>
            <button onClick={addToCart} className="btn-large">
              Add to Cart - ₹{product.price * quantity}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ========================================
// CART PAGE
// ========================================
function CartPage() {
  const [cart, setCart] = useState({ items: [] });
  const [total, setTotal] = useState(0);
  const userId = localStorage.getItem('userId');
  const navigate = useNavigate();

  useEffect(() => {
    if (userId) fetchCart();
  }, [userId]);

  const fetchCart = async () => {
    try {
      const response = await axios.get(`${API_URL}/cart/${userId}`);
      setCart(response.data.cart);
      setTotal(response.data.total);
    } catch (error) {
      console.error('Error fetching cart:', error);
    }
  };

  const updateQuantity = async (itemId, newQuantity) => {
    try {
      await axios.post(`${API_URL}/cart/update`, {
        userId,
        itemId,
        quantity: newQuantity
      });
      fetchCart();
    } catch (error) {
      alert('Error updating cart');
    }
  };

  const removeItem = async (itemId) => {
    try {
      await axios.post(`${API_URL}/cart/remove`, {
        userId,
        itemId
      });
      fetchCart();
    } catch (error) {
      alert('Error removing item');
    }
  };

  if (!userId) {
    return (
      <div className="empty-cart">
        <p>Please login to view your cart</p>
        <Link to="/login" className="btn-large">Login</Link>
      </div>
    );
  }

  if (cart.items.length === 0) {
    return (
      <div className="empty-cart">
        <h2>Your cart is empty</h2>
        <Link to="/" className="btn-large">Continue Shopping</Link>
      </div>
    );
  }

  return (
    <div className="cart-page">
      <h1>Shopping Cart</h1>
      
      <div className="cart-container">
        <div className="cart-items">
          {cart.items.map(item => (
            <div key={item.id} className="cart-item">
              <img src={item.product?.image} alt={item.product?.name} />
              <div className="item-details">
                <h3>{item.product?.name}</h3>
                <p>₹{item.product?.price}</p>
              </div>
              <div className="item-quantity">
                <button onClick={() => updateQuantity(item.id, item.quantity - 1)}>−</button>
                <span>{item.quantity}</span>
                <button onClick={() => updateQuantity(item.id, item.quantity + 1)}>+</button>
              </div>
              <div className="item-total">
                ₹{(item.product?.price || 0) * item.quantity}
              </div>
              <button onClick={() => removeItem(item.id)} className="btn-remove">Remove</button>
            </div>
          ))}
        </div>

        <div className="cart-summary">
          <h2>Order Summary</h2>
          <div className="summary-row">
            <span>Subtotal:</span>
            <span>₹{total}</span>
          </div>
          <div className="summary-row">
            <span>Shipping:</span>
            <span>₹100</span>
          </div>
          <div className="summary-row">
            <span>Tax:</span>
            <span>₹{Math.round(total * 0.1)}</span>
          </div>
          <div className="summary-row total">
            <span>Total:</span>
            <span>₹{total + 100 + Math.round(total * 0.1)}</span>
          </div>
          <button onClick={() => navigate('/checkout')} className="btn-large">
            Proceed to Checkout
          </button>
        </div>
      </div>
    </div>
  );
}

// ========================================
// CHECKOUT PAGE
// ========================================
function CheckoutPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    address: '',
    city: '',
    postalCode: ''
  });
  const [loading, setLoading] = useState(false);
  const userId = localStorage.getItem('userId');
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Create order
      const cartResponse = await axios.get(`${API_URL}/cart/${userId}`);
      const { items } = cartResponse.data.cart;
      const { total } = cartResponse.data;

      const orderResponse = await axios.post(`${API_URL}/orders/create`, {
        userId,
        items,
        total: total + 100 + Math.round(total * 0.1),
        shippingAddress: formData
      });

      const orderId = orderResponse.data.order.id;
      navigate(`/payment/${orderId}`);
    } catch (error) {
      alert('Error creating order');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="checkout-page">
      <h1>Checkout</h1>
      
      <form onSubmit={handleSubmit} className="checkout-form">
        <div className="form-group">
          <label>Full Name</label>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label>Email</label>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label>Address</label>
          <input
            type="text"
            name="address"
            value={formData.address}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-row">
          <div className="form-group">
            <label>City</label>
            <input
              type="text"
              name="city"
              value={formData.city}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label>Postal Code</label>
            <input
              type="text"
              name="postalCode"
              value={formData.postalCode}
              onChange={handleChange}
              required
            />
          </div>
        </div>

        <button type="submit" disabled={loading} className="btn-large">
          {loading ? 'Processing...' : 'Continue to Payment'}
        </button>
      </form>
    </div>
  );
}

// ========================================
// MAIN APP COMPONENT
// ========================================
function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(!!localStorage.getItem('token'));
  const [userName, setUserName] = useState(localStorage.getItem('userName') || '');
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('userId');
    localStorage.removeItem('userName');
    setIsLoggedIn(false);
    navigate('/');
  };

  return (
    <div className="app">
      <header className="header">
        <div className="header-container">
          <Link to="/" className="logo">
            <FiBox size={24} /> eShop
          </Link>

          <nav className="nav">
            <Link to="/">
              <FiHome /> Home
            </Link>
            <Link to="/cart">
              <FiShoppingCart /> Cart
            </Link>
          </nav>

          <div className="auth-section">
            {isLoggedIn ? (
              <>
                <span className="user-greeting">Hi, {userName}!</span>
                <button onClick={handleLogout} className="btn-logout">
                  <FiLogOut /> Logout
                </button>
              </>
            ) : (
              <>
                <Link to="/login" className="btn-auth">Login</Link>
                <Link to="/register" className="btn-auth">Sign Up</Link>
              </>
            )}
          </div>
        </div>
      </header>

      <main className="main">
        <Routes>
          <Route path="/" element={<ProductsPage />} />
          <Route path="/cart" element={<CartPage />} />
          <Route path="/checkout" element={<CheckoutPage />} />
        </Routes>
      </main>

      <footer className="footer">
        <p>© 2024 eShop. All rights reserved. | Professional E-Commerce Platform</p>
      </footer>
    </div>
  );
}

export default App;
